print("por favor digite um ano bissesto")
ano=int(input())
if(ano%4==0 and ano%100!=0 or ano%400==0):
  print("o ano digitado é bissesto")
else:
  print("o ano digitado não é bissesto")
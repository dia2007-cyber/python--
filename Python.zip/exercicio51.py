print("por favor digite um numero primo: ")
numero = int(input())
if(numero/numero and numero/1):
  print("o numero digitado é primo")
else:
  print("o numero digitado não é primo")

print("digite o ano do seu nascimento:")
ano=int(input())
print("digite o ano  atual: ")
anoatual=int(input())
print("sua idade é",anoatual-ano)
idade=anoatual-ano
idade_meses=idade*12
print("sua idade em meses é",idade_meses)
idade_dias=idade*365
print("sua idade em dias é",idade_dias)
idade_horas=idade_dias*24
print("sua idade em horas é",idade)
idade_minutos=idade_horas*60
print("sua idade em minutos é",idade)
idade_segundos=idade_minutos*60
print("sua idade em segundos é",idade)

pares=0
impares=0
for _i in range(10):
  print("digite um numero")
  numero=int(input())
  if(numero%2==0):
    pares=pares+1
  else:
    impares=impares+1
print("os numeros pares são",pares)
print("os numeros impares são",impares)
      
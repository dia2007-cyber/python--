print("digite o valor em metros que deseja converter para centimetros")
metros=float(input())
print("o valor em centimetros é",metros*100)

print("digite o valor do primeiro lado do triangulo")
lado1=int(input())
print("digite o valor do segundo lado do triangulo")
lado2=int(input())
print("digite o valor do terceiro lado do triangulo")
lado3=int(input())
if(lado1==lado2 and lado2==lado3):
  print("o triangulo é equilatero")
elif(lado1 in (lado2, lado3) or lado2 == lado3):
  print("o triangulo é isosceles")
else:
  print("o triangulo é escaleno")


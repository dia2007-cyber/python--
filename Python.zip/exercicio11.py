print("digite o primeiro numero")
numero=int(input())
if(numero/2==0):
   print("o numero digitado é par")
elif(numero/2==1):
   print("o numero digitado é impar")

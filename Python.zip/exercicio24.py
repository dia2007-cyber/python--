print("digite o valor do lado do quadrado:")
lado=int(input())
print("a area do quadrado é",lado*lado)

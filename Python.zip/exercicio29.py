print("digite o primeiro numero: ")
numero1=int(input())
print("digite o segundo numero: ")
numero2=int(input())
print("digite o terceiro numero: ")
numero3=int(input())
resultado=numero1*numero2*numero3
print("o resultado da multiplicação é",resultado)


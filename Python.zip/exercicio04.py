numero1=int(input("Digite o primeiro numero: "))
numero2=int(input("Digite o segundo numero: "))
if(numero1>=numero2):
  print("o primeiro numero digitado é o maior")
else:
  print("o segundo numero digitado é o maior")
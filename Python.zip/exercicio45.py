nome=input ("digite seu nome:")

for letra in nome:
  print(letra)
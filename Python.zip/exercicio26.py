print("digite o primeiro numero maiorr do que zero")
numero1=int(input())
base=numero1
print("digite o segundo numero maior do que zero")
numero2=int(input())
expoente=numero2
print("o resultado da potencia é",numero1 ,"elevado ao : " ,numero2,  " é: ",resultado)
print("por favor digite o primeiro numero: ")
numero1=int(input())
print("por favor digite o segundo numero: ")
numero2=int(input())
print("\n")
for i in range (numero1,numero2):
    print(i)      
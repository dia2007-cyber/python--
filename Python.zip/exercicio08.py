print("digite uma letra")
letra=input()
if (letra=="a" or letra=="e" or letra=="i" or letra=="o" or letra=="u"):
  print("a letra digitada é uma vogal")
else:
  print("a letra digitada é uma consoante")
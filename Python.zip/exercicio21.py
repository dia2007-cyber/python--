print("digite o valor de a")
a=int(input())
print("digite o valor de b")
b=int(input())
print("digite o valor de c")
c=int(input())
delta=b**2-4*a*c
if(delta<0):
  print("nao existe raiz real")
elif(delta==0):
  print("existe uma raiz real")
else:
  print("existem duas raizes reais")


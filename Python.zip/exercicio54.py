#Faça um algoritmo que leia uma quantidade indeterminada de números positivos e conte
#quantos deles estão nos seguintes intervalos: [0-25], [26-50], [51-75] e [76-100] A 
#entrada de dados deverá terminar quando for lido um número negativo.

print("digite um numero positivo: " )
numero=int(input())
if(numero>=0 and numero<=25):
  print("o numero digitado esta entre 0 e 25")
elif(numero>=26 and numero<=50):
  print("o numero digitado esta entre 26 e 50")
elif(numero>=51 and numero<=75):
  print("o numero digitado esta entre 51 e 75")
elif(numero>=76 and numero<=100):
  print("o numero digitado esta entre 76 e 100")
else:
  print("o numero digitado é negativo")


print("digite o valor do raio do circulo: ")
raio=float(input())
area=3.14*(raio**2)
print("a area do circulo é",area)
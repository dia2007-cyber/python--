print("digite uma palavra:")
palavra=input()
palavra_invertida=palavra[::-1]

if(palavra==palavra_invertida):
  print("a palavra digitada é um palindromo")  
else:
  print("a palavra digitada não é um palindromo")

#(Com  matriz e ordenação) Use como base o Exercício 67 e elabore a saída de 
#classificação de acordo com os critérios de desempate: Mais Pontos, Mais Vitórias,
#Mais Saldo de Gols,Mais Gols Pro, em caso de empate, realize um sorteio entre os times.

print("[1;35;40mTabela de times.")
tabela = dict()

quantidade = 1
desempenho = []
for i in range(0,quantidade):
   time = input("[1;37;40mInforme o nome do time:")
   if time not in tabela:
    for c in range(0,5):
      if c == 0:
        info = int(input ("[1;37;40mInforme a quantidade de vitórias: "))
      elif c == 1:
        info = int(input ("[1;37;40mInforme a quantidade de empates: "))  
      elif c ==2:
        info = int(input("[1;37;40mInforme a quantidade de derrotas: "))
      elif c ==3:
        info = int(input("[1;37;40mInforme a quantidade de gols próprios: "))  
      elif c == 4:
        info = int(input("[1;37;40mInforme a quantidade de gols contras: ")) 
      desempenho.append(info)
    print()
    desempenho.insert(0, desempenho[0]*3 + desempenho[1])
    desempenho.append(desempenho[-2] - desempenho[-1])  
    tabela[time] = desempenho
    #tabela[time] = {"Pontos": desempenho[0], "Vitórias": desempenho[1], "Empates":
   #  desempenho[2], "Gols Próprio" : desempenho[3], "Gols Contra" : 
    #" desempenho[4], "Saldo": desempenho[5]}"
    desempenho = []

print(tabela)

     

for nomeDoTime, desempenho in tabela.items():
  time = nomeDoTime 
  pontos, vitorias, empates, derrotas, golspro,golscontra,saldo = desempenho
  print(("{:<10}  {:<10}  {:<10}  {:<10}  {:<10} {:<10}  {:<10}  {:<10}"
  .format(time,     pontos,vitorias, empates, derrotas, golspro, golscontra,saldo)))

                                                                                                                                                                                                 
print("Telefonou para a vítima?: ") 
resposta1 = input()
print("Esteve no local do crime?: ")
resposta2 = input()
print("Mora perto da vítima?: ")
resposta3 = input()
print("Devia para a vítima?: ")
resposta4 = input()
print( "Já trabalhou com a vítima?: ")
resposta5 = input()
if(resposta1=="sim" and resposta2=="sim" 
and resposta3=="sim" and resposta4=="sim" and resposta5=="sim" ):
  print("voce é o assassino")
elif(resposta1=="sim" and resposta2=="sim" 
and resposta3=="sim" and resposta4=="nao" and resposta5=="nao"):
  print("voce é o cumplice")
elif(resposta1=="sim" and resposta2=="sim"
and resposta3=="nao" and resposta4=="nao" and resposta5=="nao"):
     print("voce é o suspeito")
elif(resposta1=="sim" and resposta2=="nao" 
and resposta3=="nao" and resposta4=="nao" and resposta5=="nao" ):
  print("voce é inocente")
else:
  print("voce é inocente")

print("digite um numero positivo maior do que zero:")
numero=int(input())
if(numero>0):
  print("o numero digitado é positivo")
else:
  print("o numero digitado é negativo")

#Faça um algoritmo que solicite ao usuário a digitação de um número 
#até 99 e imprima-o na tela por extenso.

def numero_por_extenso(num):
  unidades = [
  "zero", "um", "dois", "três", "quatro", "cinco",
  "seis", "sete", "oito", "nove"
  ]
  dezenas = [
   "", "dez", "vinte", "trinta", "quarenta", "cinquenta",
   "sessenta", "setenta", "oitenta", "noventa"
  ]
  especiais = {
    10: "dez", 11: "onze", 12: "doze", 13: "treze",
    14: "quatorze", 15: "quinze", 16: "dezesseis",
    17: "dezessete", 18: "dezoito", 19: "dezenove"
  }

  if 0 <= num < 10:
   return unidades[num]
  elif 10 <= num < 20:
   return especiais[num]
  elif 20 <= num < 100:
      dezena = num // 10
      unidade = num % 10
      return dezenas[dezena] + ('' if unidade == 0 else ' e ' + unidades[unidade])
  else:
   return "Número fora do intervalo"

numero = int(input("Digite um número entre 0 e 99: "))

if 0 <= numero < 100:
  print(f"O número {numero} por extenso é: {numero_por_extenso(numero)}.")
else:
  print("Número fora do intervalo permitido.")



























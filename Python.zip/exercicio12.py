print("digite o primeiro numero")
numero=int(input())
if(numero>0):
   print("positivo")
elif(numero<0):
   print("negativo")
else:
   print("zero")
print("por favor digite um numero de 1 a 7: ")
numero=int(input())
if(numero==1):
  print("domingo")
elif(numero==2):
  print("segunda-feira")
elif(numero==3):
  print("terça-feira")
elif(numero==4):
  print("quarta-feira")
elif(numero==5):
  print("quinta-feira")
elif(numero==6):
  print("sexta-feira")
elif(numero==7):
  print("sabado")
else:  
  print("numero invalido")
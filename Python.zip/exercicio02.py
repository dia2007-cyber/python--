nome = input("Digite seu nome: ")
print("ola",nome)
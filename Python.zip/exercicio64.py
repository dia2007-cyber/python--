#(Com vetor) Faça um algoritmo que armazene todas as consoantes 
#de uma palavra que o usuário informar.
print("digite uma palavra:")
palavra=input()
consoantes=[]
for letra in palavra:
  if(letra not in "aeiou"):
    consoantes.append(letra)
print("as consoantes da palavra são:",consoantes)
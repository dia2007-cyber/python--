print("digite o salario base")
salario_base=float(input())
print("o valor do salario + gratificacao é",salario_base*1.05)
novo_salario=salario_base*1.05
print("o valor do salario + imposto é",novo_salario*0.93)
salario_final=novo_salario*0.93
print("o salario final é",salario_final)

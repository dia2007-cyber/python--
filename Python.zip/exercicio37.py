print("por favor digite o valor de a: ")
a=int(input())
print("por favor digite o valor de b: ")
b=int(input())
print("por favor digite o vallor de c: ")
c=int(input())
if(a==0):
 print("não é uma equação do segundo grau")
else:
  delta=b*b-4*a*c
  print("o valor de delta é",delta)
  if(delta<0):
    print("não existe raiz real")
  elif(delta==0):
    print("existe uma raiz real")
  else:
    print("existe duas raizes reais")

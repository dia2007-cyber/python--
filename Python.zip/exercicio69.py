import random

print("\033[1;35;40mTabela de times.")

tabela = {}

# Coleta de dados
quantidade = int(input("Informe a quantidade de times: "))
for _ in range(quantidade):
    time = input("\033[1;37;40mInforme o nome do time: ")

    if time not in tabela:
      desempenho = []
      desempenho.append(int(input("\033[1;37;40mInforme a quantidade de vitórias: ")))
      desempenho.append(int(input("\033[1;37;40mInforme a quantidade de empates: "))) 
      desempenho.append(int(input("\033[1;37;40mInforme a quantidade de derrotas: ")))
      desempenho.append(int(input("\033[1;37;40mInforme a quantidade de gols próprios:"
                                 )))
      desempenho.append(int(input("\033[1;37;40mInforme a quantidade de gols contra: "
                                 )))

     # Cálculo de pontos e saldo de gols
      pontos = desempenho[0] * 3 + desempenho[1]  # Pontos
      saldo = desempenho[3] - desempenho[4]       # Saldo de Gols
      desempenho = [pontos] + desempenho + [saldo]  # [Pontos, Vitórias, Empates, 
                                 # Derrotas, Gols Próprios, Gols Contra, Saldo]

      tabela[time] = desempenho

print("\nTabela de Classificação:")
print("{:<10}  {:<10}  {:<10}  {:<10}  {:<10} {:<10}  {:<10}  {:<10}".format(
    "Time", "Pontos", "Vitórias", "Empates", "Derrotas", "Gols Próprios", "Gols Contra",
    "Saldo"))

# Classificação dos times
classificacao = sorted(tabela.items(), key=lambda x: (x[1][0], x[1][1], x[1][7],x[1][3])
                       , reverse=True)

# Tratando empates com sorteio
times_empate = []
for i in range(len(classificacao)):
    if i > 0 and classificacao[i][1] == classificacao[i - 1][1]:
        times_empate.append(classificacao[i][0])
    else:
        if len(times_empate) > 0:
          sorteio =random.choice(times_empate)
          print(f"Sorteio entre: {', '.join(times_empate)}.Time classificado:{sorteio}")
        times_empate = []
    print("{:<10}  {:<10}  {:<10}  {:<10}  {:<10} {:<10}  {:<10}  {:<10}".format(
            classificacao[i][0], *classificacao[i][1]))

# Último empate, se existir
if len(times_empate) > 0:
    sorteio = random.choice(times_empate)
    print(f"Sorteio entre: {', '.join(times_empate)}. Time classificado: {sorteio}")
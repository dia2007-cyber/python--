#print("por favor digite um numero: ")
#numero=int(input())
#numeros_primos = []
divisoes=[]
def is_prime(numero):
    if numero < 2:
        return False
    return all(numero % i != 0 for i in range(2, int(numero ** 0.5) + 1))
for i in range(2, numero + 1):
    if is_prime(i):
        numeros_primos.append(i)
print(f"Os números primos entre 2 e {numero} são: {numeros_primos}")
print("digite o primeiro numero")
numero1=int(input())

# nao sei como fazer para achar as divisoes feita dentro da funcao is_prime  

print(f"as divisoes feitas para achar os numeros primos foram:  {divisoes}")
print("por favor digite um numero inteiro menor do que 100 : ")
numero=int(input())
if(numero>=1000):
  print("por favor digite um numero menor do que 100: ")

centenas=numero//100
dezenas=(numero%100)//10
unidades=numero%10
print("centenas",centenas)
print("dezenas",dezenas)
print("unidades",unidades)
 
print("digite o valor da base de um triangulo")
base=int(input())
print("digite o valor da altura de um triangulo: ")
altura=int(input())
print("a area do triangulo é",(base*altura)/2)
 
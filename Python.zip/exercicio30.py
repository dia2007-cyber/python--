print("digite sua idade: ")
idade=int(input())
if(idade>18):
  print("vc é maior de idade")
else:
  print("vc é menor de idade")
def fibonaccirecursive(n):
    if n == 0:
        return 0
    elif n == 1:
        return 1
    else:
        return fibonaccirecursive(n - 1) + fibonaccirecursive(n - 2)
print("digite o numero de termos da sequencia de fibonacci")
n = int(input())
for i in range(n):
    print(fibonaccirecursive(i))

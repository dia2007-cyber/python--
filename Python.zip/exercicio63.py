numeros_inpares= []
for i in range(1,101):
  if i % 2 != 0:
    numeros_inpares.append(i)
print(numeros_inpares)

print("digite o primeiro numero")
numero1=int(input())
print("digite o segundo numero")
numero2=int(input())
print("digite o terceiro numero")
numero3=int(input())
if(numero1>numero2 and numero1>numero3):
  print("o primeiro numero digitado é o maior",numero1)
elif(numero2>numero1 and numero2>numero3):
  print("o segundo numero digitado é o maior",numero2)
else:
  print("o terceiro numero digitado é o maior",numero3)
  

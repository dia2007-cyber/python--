print("digite um numero: ")
numero=int(input())
# verificar se o numero é menoe que 0
if(numero<0):
  print("nao é possivel calcular o fatorias de um numero negativo")
#calcular o fatorial
else:
  fatorial=1
  for i in range(1,numero+1):
    fatorial=fatorial*i
  print("o fatorial de",numero,"é",fatorial)



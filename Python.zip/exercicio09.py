print("digite o primeiro numero")
numero1=int(input())
print("digite o segundo numero")
numero2=int(input())
print("digite o terceiro numero")
numero3=int(input())
print("digite o operador de soma + ")
operador=input()
if(operador=="+"):
  print("a soma dos numeros é",numero1+numero2+numero3)
  
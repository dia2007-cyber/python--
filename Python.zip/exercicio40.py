print("por favor digite um numero entre 0 e 10:")
numero=int(input())
if(numero<0 and numero>10):
  print("o numero digitado é invalido")
  print("por favor digite um numero entre 0 e 10: ")

  print(" PARABEMS VOCE ACERTOU ")
  
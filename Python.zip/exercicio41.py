print("digite o primeiro numero")
numero1=int(input())
print("digite o segundo numero")
numero2=int(input())
print("digite o terceiro numero")
numero3=int(input())
print("digite o quarto numero")
numero4=int(input())
print("digite o quinto numero")
numero5=int(input())
if(numero1>numero2 and numero1>numero3 and numero1>numero4 and numero1>numero5):
  print("o maior numero é",numero1)
elif(numero2>numero1 and numero2>numero3 and numero2>numero4 and numero2>numero5):
  print("o maior numero é",numero2)
elif(numero3>numero1 and numero3>numero2 and numero3>numero4 and numero3>numero5):
  print("o maior numero é",numero3)
elif(numero4>numero1 and numero4>numero2 and numero4>numero3 and numero4>numero5):
  print("o maior numero é",numero4)
elif(numero5>numero1 and numero5>numero2 and numero5>numero3 and numero5>numero4):
  print("o maior numero é",numero5)
else:
  print("os numeros são iguais")



print("digite o primeiro numero")
numero1=int(input())
print("digite o segundo numero")
numero2=int(input())
print("digite a operaçao desejada + para soma, - para subtraçao")
operacao=input()
if(operacao=="+"):
  print("a soma dos numeros é",numero1+numero2)
elif (operacao=="-"):
  print("a subtracao dos numeros é",numero1-numero2)
else :
 print("operacao invalida")
  
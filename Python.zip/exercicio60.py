print("Digite um numero inteiro da tabuada: ")
numero=int(input())
print("Digite o numero inicial da tabuada: ")
inicio=int(input())
print("Digite o numero final da tabuada: ")
final=int(input())
if(final<inicio):
  print("O numero final da tabuada deve ser maior que o inicial")
else:
  for i in range(inicio,final+1):
    print(numero,"X",i,"=",numero*i)

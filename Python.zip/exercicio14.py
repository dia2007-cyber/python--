print("Digite 'm' para masculino e 'f' para feminino")
sexo=input()
if(sexo=="m"):
  print("masculino")
elif(sexo=="f"):
  print("feminino")
else:
  print("sexo invalido")


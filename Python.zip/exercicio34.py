print("por favor digite sua altura: ")
altura=float(input())
print("por favor digite o sexo " + "(M para masculino e F para feminino): ")
sexo=input()
if(sexo=="M"):
  peso=(72.7*altura)-58
  print("seu peso ideal é",peso)
elif(sexo=="F"):
  peso=(62.1*altura)-44.7
  print("seu peso ideal é",peso)
else:
  print("sexo invalido")
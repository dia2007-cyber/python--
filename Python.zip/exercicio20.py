print("em qual turno voce estuda?")
print("digite M-matutino, V-vespertino ou N-noturno")
turno=input()
if(turno=="M"):
  print("bom dia")
elif(turno=="V"):
  print("boa tarde")
elif(turno=="N"):
  print("boa noite")
else:
  print("valor invalido")
  
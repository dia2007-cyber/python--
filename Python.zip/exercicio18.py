print("digite o valor do deposito ")
deposito=float(input())
print("digite o valor da taxa de juros")
taxa_de_juros=float(input())
rendimento=deposito*taxa_de_juros/100
valor_final=deposito+rendimento
print("o valor do rendimento é",rendimento)
print("o valor final é",valor_final)
      
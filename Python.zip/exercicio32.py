print("digite uma temperatuda em graus celsius: ")
celsius=float(input())
fahrenheit = celsius * 9/5 + 32
kelvin = celsius + 273.15 
print("a temperatura em fahrenheit é",fahrenheit)
print("a temperatura em kelvin é",kelvin)
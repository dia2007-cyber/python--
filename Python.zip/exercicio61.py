#Com vetor) Faça um algoritmo que leia 4 notas, com casas decimais
#armazenadas em um vetor.
#Calcule a média dos valores lidos;
#imprimia a média;
#imprima os elementos do vetor que são maiores do que a média calculada.

print("Digite a primeira nota: ")
nota1=float(input())
print("Digite a segunda nota: ")
nota2=float(input())
print("Digite a terceira nota: ")
nota3=float(input())
print("Digite a quarta nota: ")
nota4=float(input())
soma=(nota1+nota2+nota3+nota4)
media=(soma/4)
print("A media das notas é",media)

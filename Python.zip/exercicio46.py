print("por favor digite um numero para ver a tabuada desse numero: ")
numero=int(input())
print("\n")
cores  = {
    'limpa' : '\033[m',
    'azul' :  '\033[34m',
    'amarelo' : '\033[33m',
    'pretoebranco' :'\033[7;30m',
}  
print(f" {cores['azul']} tabuada {cores['limpa']}")
print("\n")
print(numero,"x 1 =",numero*1)
print(numero,"x 2 =",numero*2)
print(numero,"x 3 =",numero*3)
print(numero,"x 4 =",numero*4)
print(numero,"x 5 =",numero*5)
print(numero,"x 6 =",numero*6)
print(numero,"x 7 =",numero*7)
print(numero,"x 8 =",numero*8)
print(numero,"x 9 =",numero*9)
print(numero,"x 10 =",numero*10)

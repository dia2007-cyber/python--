
votos_brancos=0
votos_nulos=0
votos_validos=0
votos_brancos=0
votos_nulos=0
candidato1=0
candidato2=0
candidato3=0
candidato4=0
branco=0
nulo=0
votos=0
quantidade_de_eleitores=int(input("digite a quantidade de eleitores: "))
for _i in range(quantidade_de_eleitores):
  voto=int(input("digite o seu voto: "))
  if(voto==1):
    print("voce votou no candidato 1")
    candidato1=candidato1+1
  elif(voto==2):
    print("voce votou no candidato 2")
    candidato2=candidato2+1
  elif(voto==3):
    print("voce votou no candidato 3")
    candidato3=candidato3+1
  elif(voto==4):
    print("voce votou nulo")
    nulo=nulo+1
  elif(voto==5):
    print("voce votou branco")
    branco=branco+1
  else:
    print("opçao invalida")

votos_validos=candidato1+candidato2+candidato3+branco+nulo
porcentagem_de_votos_brancos=(branco/votos_validos)*100
porcentagem_de_votos_nulos=(nulo/votos_validos)*100
print("a porcentagem de votos brancos é",votos_brancos)
print("a porcentagem de votos nulos é",votos_nulos)
print("a quantidade de votos validos é",votos)
print("a quantidade de votos brancos é",branco)
print("a quantidade de votos nulos é",nulo)
print("a quantidade de votos do candidato 1 é",candidato1)
print("a quantidade de votos do candidato 2 é",candidato2)
print("a quantidade de votos do candidato 3 é",candidato3)
  